#!/bin/bash

# Azure build script for HMI Agent
echo "Starting Azure build process..."

# Set proper permissions
mkdir -p /tmp/.npm
export npm_config_cache=/tmp/.npm

# Install backend dependencies
echo "Installing backend dependencies..."
npm install --no-optional

# Install and build frontend
echo "Installing frontend dependencies..."
cd frontend
npm install --no-optional --cache /tmp/.npm

echo "Building frontend..."
npm run build

# Go back to root
cd ..

echo "Build completed successfully!" 